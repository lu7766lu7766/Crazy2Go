<?php
class Main_Controllers {

	public function __construct($base) {
		$this->base = $base;
	}

	public function home() {
		
	}
	
	public function ajax_getrate() {
		require_once "swop/models/exchange.php";
		$swop = new Main_Models();
		$swop->ajax_getrate();
		
		echo $swop->exchange_rate;
	}
}
?>