/*$(document).ready(function(){
	loadCSS = function(href) {
	    var cssLink = $("<link rel='stylesheet' type='text/css' href='"+href+"'>");
		$("head").append(cssLink); 
	};
	
	loadJS = function(src) {
	    var jsLink = $("<script type='text/javascript' src='"+src+"'>");
	    $("head").append(jsLink); 
	};
	loadJS("../public/js/jquery.qtip.min.js");
	loadCSS("../public/css/jquery.qtip.min.css");
	
	var site_url = "http://www.crazy2go.com/";
	var control_name = "history_log";
	var page_now = document.URL;
	//console.log(site_url+control_name+"/ajax_get_history"+"^^"+page_now)
	$.post(site_url+control_name+"/ajax_get_history", {
		page_now:page_now
		},function(data) {
			var error = data.error||0;
			if(error > 0) {
				console.log(data.message+"\n"+data.add.陣列名稱);
			}else{
				var len = data.length;
				for(i=0;i<len;i++){
					var click_times = Number($(data[i]).attr("click_times"))||0
					if($(data[i]).is(":hidden"))continue;
					if(click_times==0){
						$times_box = $("<div class='times_box'></div>")
						$times_box.css({
							"position":		"absolute",
							"border":		"1px solid rgb(255, 175, 115)",
							"background":	"rgba(115, 175, 255, 0.7)",
							"color":		"#333",
							"font-weight": 	"bold",
							"-webkit-text-stroke": "1px #fff",
							"width":		$(data[i]).width()-2,
							"height":		$(data[i]).height()-2,
							"line-height":	$(data[i]).height()+"px",
							"float":		"left",
							"top":			$(data[i]).offset().top,
							"left":			$(data[i]).offset().left,
							"text-align":	"center",
							"z-index":		2
						}).hover(function(){
								$(this).stop(true).slideToggle("5000");
							},function(){
								$(this).stop(true).slideToggle("5000");
						});
						$(data[i]).after($times_box).hover(function(){
								console.log("obj_mouse_in")
								$box = $(this).next();
								$box.stop(true).slideToggle("5000");
							},function(){
								$box = $(this).next();
								$box.stop(true).slideToggle("5000");
						});
					}else{
						$times_box = $(data[i]).next();
					}
					
					$(data[i]).attr("click_times",click_times+1);
					$times_box.attr("click_times",click_times+1).html(click_times+1);
					//$(data[i]).append($(data[i]).attr("click_times"))
				}
				//if($("*[click_times][class='times_box']").length>0){
				//	$("body").append("<div>")
				//}
			}
			
		},"json"
	);
	
})*/
////////////////////////////////////////////////

/*$(document).ready(function(){
	
	loadCSS = function(href) {
	    var cssLink = $("<link rel='stylesheet' type='text/css' href='"+href+"'>");
		$("head").append(cssLink); 
	};
	
	loadCSS("public/css/jquery.qtip.css");
	
	$.getScript("public/js/jquery.qtip.js",function(){
		var site_url = "http://www.crazy2go.com/";
		var control_name = "history_log";
		var func_name = "ajax_get_history";
		var page_now = document.URL;
		//console.log(site_url+control_name+"/ajax_get_history"+"^^"+page_now)
		$.post(site_url+control_name+"/"+func_name, {
			page_now:page_now
			},function(data) {
				var error = data.error||0;
				if(error > 0) {
					console.log(data.message+"\n"+data.add.陣列名稱);
				}else{
					var len = data.length;
					for(i=1;i<len;i++){
						var click_times = Number( $(data[i]).data("click_times") )|| 0;
						if( $(data[i]).is(":hidden") || $(data[i]).length==0 )continue;
						if(click_times==0){
							$times_box = $("<div class='times_box "+data[i]+"'></div>")
							$times_box.css({
								"position":		"absolute",
								"border":		"1px solid rgb(255, 175, 115)",
								"background":	"rgba(115, 175, 255, 0.7)",
								"width":		$(data[i]).width(),
								"height":		$(data[i]).height(),
								"line-height":	$(data[i]).height()+"px",
								"float":		"left",
								"top":			$(data[i]).offset().top-2,
								"left":			$(data[i]).offset().left-2,
								"pointer-events":"none",
								"z-index":		2
							})
							$("body").append($times_box);
							$(data[i]).qtip({
								//content: "1",
								content: String( Math.floor((click_times+1)*100*10/len)/10)+"%",
							    position: {
							        my: 'bottom right',
							        at: 'top left',
							        viewport: $(window),
									adjust: { method: 'shift' }
								},
							    show: true,
							    hide:false
							});
				            //$($(data[i]).tooltipster('elementTooltip'))
						}
						$(data[i]).attr("click_times",click_times+1)
						$(data[i]).data("click_times",click_times+1);
						$(data[i]).qtip('option', 'content.text', String( Math.floor((click_times+1)*100*10/len)/10)+"%" );
						//console.log($(data[i]).qtip('option', 'content.text'))
					}
				}
				
			},"json"
		);
	})
})*/

/////////////////////////////////////////////////////////////////////////////////////////ver3.0
/*
$(document).ready(function(){
	$.extend({
		getUrlVars: function(){
			var vars = [], hash;
			var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
			for(var i = 0; i < hashes.length; i++){
		    	hash = hashes[i].split('=');
				vars.push(hash[0]);
				vars[hash[0]] = hash[1];
	    	}
			return vars;
		},
		getUrlVar: function(name){
			return $.getUrlVars()[name];
		}
	});
	
	loadCSS = function(href) {
	    var cssLink = $("<link rel='stylesheet' type='text/css' href='"+href+"'>");
		$("head").append(cssLink); 
	};
	
	var burden_doc = "";
	if(window.location.href.substr(-1)!='/'){
		var url = window.location.href;
		url = url.substring(url.lastIndexOf('/')+1);
		if( url.indexOf('?')==-1 && url.indexOf('.')==-1 && url.indexOf('#')==-1){
			burden_doc = '/';
		}
	}
	
	var site_url = "http://www.crazy2go.com/";
	var tooltipJS_src = site_url+"public/js/jquery.qtip.js";
	var tooltipCSS_src = site_url+"public/css/jquery.qtip.css";
	var toolbar_btn_css = 
		"<style type='text/css'>"+
			".history_btn {"+
				"-moz-box-shadow:inset 0px 1px 0px 0px #fceaca;"+
				"-webkit-box-shadow:inset 0px 1px 0px 0px #fceaca;"+
				"box-shadow:inset 0px 1px 0px 0px #fceaca;"+
				"background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #ffce79), color-stop(1, #eeaf41) );"+
				"background:-moz-linear-gradient( center top, #ffce79 5%, #eeaf41 100% );"+
				"filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#ffce79', endColorstr='#eeaf41');"+
				"background-color:#ffce79;"+
				"-webkit-border-top-left-radius:8px;"+
				"-moz-border-radius-topleft:8px;"+
				"border-top-left-radius:8px;"+
				"-webkit-border-top-right-radius:8px;"+
				"-moz-border-radius-topright:8px;"+
				"border-top-right-radius:8px;"+
				"-webkit-border-bottom-right-radius:8px;"+
				"-moz-border-radius-bottomright:8px;"+
				"border-bottom-right-radius:8px;"+
				"-webkit-border-bottom-left-radius:8px;"+
				"-moz-border-radius-bottomleft:8px;"+
				"border-bottom-left-radius:8px;"+
				"text-indent:0px;"+
				"border:2px solid #eeb44f;"+
				"display:inline-block;"+
				"color:#ffffff;"+
				"font-family:Arial;"+
				"font-size:17px;"+
				"font-weight:bold;"+
				"font-style:normal;"+
				"height:25px;"+
				"line-height:25px;"+
				"width:25px;"+
				"text-decoration:none;"+
				"text-align:center;"+
				"text-shadow:1px 1px 1px #ce8e28;"+
				"position:relative;"+
				"top:-1px;"+
			"}"+
			".history_btn:hover {"+
				"background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #eeaf41), color-stop(1, #ffce79) );"+
				"background:-moz-linear-gradient( center top, #eeaf41 5%, #ffce79 100% );"+
				"filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#eeaf41', endColorstr='#ffce79');"+
				"background-color:#eeaf41;"+
			"}.history_btn:active {"+
				"position:relative;"+
				"top:0px;"+
			"}</style>";
	$("head").append(toolbar_btn_css); 
	
	var toolbar = "<div id='history_toolbar' style='position:absolute;width:50%;"+
						//"background:#559CD6;"+
						"background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #ccdfee), color-stop(0.4, #559CD6) );"+
						"border:3px #1373BD solid;height:35px;z-index:21;'>&nbsp;"+
						"<div style='font-size:20px;color:#fff;display:inline-block;width:auto;line-height:35px;'>總點擊數:<a id='total_click_times'>123</a>&nbsp;&nbsp;</div>"+
				  		"<div class='history_btn' id='show_mode'>%</div>&nbsp;"+
						"<div class='history_btn' id='analysis_mode'>參</div>&nbsp;"+
				  "</div>";
	var toolbar_bg = "<div id='history_toolbar_bg' style='position:absolute;top:0px;left:0px;width:100%;height:100%;background:rgb(10,10,10);z-index:20;'></div>";
	var $toolbar = $(toolbar);
	var $toolbar_bg = $(toolbar_bg);
	
	$toolbar.css({
		"top":function(){return 9-$(this).height();}
		,"left":function(){return $(window).width()/4;}
	})
	
	$toolbar_bg.css('opacity',0).hide().data("mouseType",0);
	$("body").append($toolbar_bg);
	$("body").append($toolbar);
	$.getScript(site_url+"public/js/jquery.transit.js",function(){
		$toolbar.transition({ y: '0px' ,scale: [0.35, 0.5]},300);
		$toolbar.mouseenter(function(){
			$toolbar.data("mouseType",1);
			toolbar_show();
		}).mouseleave(function(){
			$toolbar.data("mouseType",0);
			toolbar_hide();
		})
	})
	///////////////////////////////////////////////////////////////視覺設計⬆︎
	///////////////////////////////////////////////////////////////功能設計⬇︎
	
	$("#show_mode").click(function(){
		$(this).html($(this).html()=="%"?"數":"%");
		if( chg_show_mode($(this).html())===false ){
			$(this).html($(this).html()=="%"?"數":"%");
		}
	})
	
	$("#analysis_mode").data("analysis_mode",1);
	$("#analysis_mode").click(function(){
		$(this).data("analysis_mode", $(this).data("analysis_mode")==1?0:1 )
		$(this).css("color", $(this).data("analysis_mode")==1?"#fff":"#aaa");
		if( analysis()===false ){
			$(this).data("analysis_mode", $(this).data("analysis_mode")==1?0:1 )
			$(this).css("color", $(this).data("analysis_mode")==1?"#fff":"#aaa");
		}
	})
	
	function toolbar_show(){
		if( $toolbar.data("mouseType") ){
			$toolbar_bg.show().stop(true,false).transition({opacity:0.8});
			$toolbar.stop(true,false).transition({ 
				y: (-10+$toolbar.height())+'px'
				,scale: [1, 1]
			})
		}
			
	}
	
	function toolbar_hide(){
		$toolbar.stop(true,false).transition({ y: '0px' ,scale: [0.35, 0.5]});
		$toolbar_bg.stop(true,false).transition({ opacity:0,complete:function(){ if( !$toolbar.data("mouseType") )$(this).hide(); } });
	}
	
	loadCSS(tooltipCSS_src);
	
	analysis = function(){
		var tooltipJS_loaded = $("body").data("toolitpJS_loaded")||false;
		if( !tooltipJS_loaded ){
			alert("JS尚未讀取請稍待或聯絡管理員");
			return false;
		}
		var control_name = "history_log";
		var func_name = "ajax_get_history";
		var page_now = document.URL;
		var analysis_mode = $("#analysis_mode").data("analysis_mode")
		if(analysis_mode==0){
			page_now = page_now.split("?")[0];
		}
		//console.log(site_url+control_name+"/ajax_get_history"+"^^"+page_now)
		$.post(site_url+control_name+"/"+func_name, {
			page_now:page_now+burden_doc
			,analysis_mode:analysis_mode
			},function(data) {
				//console.log(data)
				var error = data.error||0;
				if(error > 0) {
					console.log(data.message+"\n"+data.add.陣列名稱);
				}else{
					var len = 0;
					for(var xpath in data){
						if (data.hasOwnProperty(xpath)) {
							if( $(xpath).is(":hidden") || $(xpath).length==0 )continue;
							len+=data[xpath];
						}
					}
					$("#total_click_times").html(len);
					$(".times_box").remove()
					$(".qtip").remove()
					for(var xpath in data){
						if (data.hasOwnProperty(xpath)) {
							if( $(xpath).is(":hidden") || $(xpath).length==0 )continue;
							var click_times = Number( data[xpath] )|| 0;
							$times_box = $("<div class='times_box "+xpath+"'></div>")
							$times_box.css({
								"position":		"absolute"
								,"border":		"1px solid rgb(255, 175, 115)"
								,"background":	"rgba(115, 175, 255, 0.7)"
								,"width":		$(xpath).width()
								,"height":		$(xpath).height()
								,"line-height":	$(xpath).height()+"px"
								,"float":		"left"
								,"top":			$(xpath).offset().top-1
								,"left":		$(xpath).offset().left-1
								,"pointer-events":"none"
								,"z-index":		2
							})
							$("body").append($times_box);
							var content = $("#show_mode").html()=="%"?String( Math.floor(click_times*100*10/len)/10)+"%":String( click_times )
							$(xpath).qtip({
								//content: "1",
								content: content
								,position: {
							        my: 'bottom right'
							        ,at: 'top left'
							        ,viewport: $(window)
							        //,adjust: { method: 'shift' }
								}
								,show: true
								,hide:false
							});
							
							$(xpath).attr("click_times",click_times);
							//$(data[xpath]).qtip('option', 'content.text', String( Math.floor(click_times*100*10/len)/10)+"%" );
						} 
						
						//console.log($(data[i]).qtip('option', 'content.text'))
					}
				}
				
			},"json"
		)
	}
	
	chg_show_mode = function(mode){
		var tooltipJS_loaded = $("body").data("toolitpJS_loaded")||false;
		if( !tooltipJS_loaded ){
			alert("JS尚未讀取請稍待或聯絡管理員");
			return false;
		}
		if(mode=="%"){
			var len = Number( $("#total_click_times").html() );
			$("*[click_times]").each(function(){
				var click_times = $(this).attr("click_times");
				var content = String( Math.floor(click_times*100*10/len)/10)+"%";
				$(this).qtip('option', 'content.text', content );
			})
			
		}else if(mode=="數"){
			$("*[click_times]").each(function(){
				$(this).qtip('option', 'content.text', $(this).attr("click_times") );
			})
		}
		
	}
	
	$.getScript( tooltipJS_src, function(){
		$("body").data("toolitpJS_loaded",true);
		analysis()
	} );
	
})
	*/
	
////////////////////////////////////////////////ver 4.0
$(document).ready(function(){
	$.extend({
		getUrlVars: function(){
			var vars = [], hash;
			var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
			for(var i = 0; i < hashes.length; i++){
		    	hash = hashes[i].split('=');
				vars.push(hash[0]);
				vars[hash[0]] = hash[1];
	    	}
			return vars;
		},
		getUrlVar: function(name){
			return $.getUrlVars()[name];
		}
	});
	
	loadCSS = function(href) {
	    var cssLink = $("<link rel='stylesheet' type='text/css' href='"+href+"'>");
		$("head").append(cssLink); 
	};
	
	var burden_doc = "";
	if(window.location.href.substr(-1)!='/'){
		var url = window.location.href;
		url = url.substring(url.lastIndexOf('/')+1);
		if( url.indexOf('?')==-1 && url.indexOf('.')==-1 && url.indexOf('#')==-1){
			burden_doc = '/';
		}
	}
	
	var site_url = "http://www.crazy2go.com/";
	var tooltipJS_src = site_url+"public/js/jquery.qtip.js";
	var tooltipCSS_src = site_url+"public/css/jquery.qtip.css";
	
	loadCSS(tooltipCSS_src);
	
	var toolbar_btn_css = 
		"<style type='text/css'>"+
			".main {"+
				"position: relative;"+
				"top:30px;"+
			"}"+
			".history_icon{"+
				"position: relative;"+
				"top: 4px;"+
				"width:16px;"+
				"margin-right: 2px;"+
			"}"+
			".history_btn{"+
				"cursor:pointer;"
			"}"+
		"</style>";
	$("head").append(toolbar_btn_css); 
	
	var hide_rect = 0;
	var hide_qtip = 0;
    var show_mode = "%";
    var analysis_mode = 1;//1含參數，0不含參數
    
    function init_btn(){
	    
	    var rect_text = hide_rect==0?"隱藏點擊範圍":"顯示點擊範圍";
	    var qtip_text = hide_qtip==0?"隱藏統計數據":"顯示統計數據";
	    var show_text = show_mode=="%"?"切換點擊數":"切換百分比";
		var analysis_text = analysis_mode==1?"切換不統計參數":"切換統計參數";
		
	    if($("#history_toolbar").length==0){
		    
			$("body").append(
				"<div style='width:100%; height: 30px; position: fixed;top:0px; z-index: 50; background-color: rgba(31, 137, 255, 0.7); border-bottom: rgba(31, 137, 255, 0.8) 1px solid; font-weight: bold; color: #fff;' id='history_toolbar'>"+
			        "<div style='width: 1225px; line-height:30px;margin: 0 auto;position: relative;'>"+
			            "<div style='left:0px; position: absolute;'>"+
			            	"<img src='"+site_url+"public/img/template/icon_chart_bar.png' class='history_icon'>"+
			                "總點擊數：<span id='total_click_times'>0</span>&nbsp;"+
			                "[<a id='hide_rect' class='history_btn'>"+rect_text+"</a>]"+
			                "[<a id='hide_qtip' class='history_btn'>"+qtip_text+"</a>]"+
			            "</div>"+
			            "<div style='right:0px; position: absolute;'>"+
			                "<div style='float: left; margin-right: 10px;' id='show_mode' class='history_btn'>"+
			                	"<img src='"+site_url+"public/img/template/icon_arrow_switch.png' class='history_icon'>"+
			                	"<a class='_text'>"+show_text+"</a>"+
			                "</div>"+
			                "<div style='float: left;' id='analysis_mode' class='history_btn'>"+
			                	"<img src='"+site_url+"public/img/template/icon_mail_server_setting.png' class='history_icon'>"+
			                	"<a class='_text'>"+analysis_text+"</a>"+
			                "</div>"+
			            "</div>"+
			        "</div>"+
			    "</div>"
			);
			
			$("#hide_rect").click(function(){
				hide_rect=hide_rect==0?1:0;
				$(".times_box").toggle();
				init_btn();
			})
			
			$("#hide_qtip").click(function(){
				hide_qtip=hide_qtip==0?1:0;
				if(hide_qtip==1)
				{
					$(".qtip").css('opacity',0);
					$(window).scroll(function(){
						$(".qtip").css('opacity',0);
					})
				}
				else
				{
					$(".qtip").css('opacity',1);
					$(window).unbind("scroll")
				}
				
				init_btn();
			})
			
			$("#show_mode").click(function(){
				show_mode=show_mode=="%"?"數":"%";
				if( chg_show_mode()===false ){
					show_mode=="%"?"數":"%";
					return;
				}
				init_btn();
			})
		
			$("#analysis_mode").click(function(){
				analysis_mode=analysis_mode==1?0:1;
				if( analysis()===false ){
					analysis_mode==1?0:1;
					return;
				}
				init_btn();
			})
	    }
	    
	    $("#hide_rect").html(rect_text);
	    $("#hide_qtip").html(qtip_text);
	    $("#show_mode").find("._text").html(show_text);
		$("#analysis_mode").find("._text").html(analysis_text);
		
    }
	
	init_btn();
	
	///////////////////////////////////////////////////////////////視覺設計⬆︎
	///////////////////////////////////////////////////////////////功能設計⬇︎
	
	analysis = function(){
		var tooltipJS_loaded = $("body").data("toolitpJS_loaded")||false;
		if( !tooltipJS_loaded ){
			alert("JS尚未讀取，請稍待或聯絡管理員");
			return false;
		}
		var control_name = "history_log";
		var func_name = "ajax_get_history";
		var page_now = document.URL;
		if(analysis_mode==0){
			var page_disget = page_now.split("?")[0];
			if( page_now == page_disget ){
				alert("本頁並沒有GET參數，因此無法使用此功能");
				return false;
			}
			page_now = page_disget;
		}
		$.post(site_url+control_name+"/"+func_name, {
			page_now:page_now+burden_doc
			,analysis_mode:analysis_mode
			},function(data) {
				var error = data.error||0;
				if(error > 0) {
					console.log(data.message+"\n"+data.add.陣列名稱);
				}else{
					var len = 0;
					for(var xpath in data){
						//data.hasOwnProperty(xpath)
						if( $(xpath).is(":hidden") || $(xpath).length==0 )continue;
						len+=data[xpath];
					}
					$(".times_box").remove()
					$(".qtip").remove()
					for(var xpath in data){
						if( $(xpath).is(":hidden") || $(xpath).length==0 )continue;
						var click_times = Number( data[xpath] )|| 0;
						$times_box = $("<div class='times_box "+xpath+"'></div>")
						$times_box.css({
							"position":		"absolute"
							,"border":		"1px solid rgb(255, 175, 115)"
							,"background":	"rgba(115, 175, 255, 0.7)"
							,"width":		$(xpath).outerWidth()
							,"height":		$(xpath).outerHeight()
							,"line-height":	$(xpath).height()+"px"
							,"float":		"left"
							,"top":			$(xpath).offset().top-1
							,"left":		$(xpath).offset().left-1
							,"pointer-events":"none"
							,"z-index":		2
						})
						$("body").append($times_box);
						var content = show_mode=="%"?String( Math.floor(click_times*100*10/len)/10)+"%":String( click_times );
						var $container = $(".main").length==0?$(window):$(".main");
						$(xpath).qtip({
							//content: "1",
							content: content
							,position: {
						        my: 'bottom right'
						        ,at: 'top left'
						        ,viewport: $container
						        //,adjust: { method: 'shift' }
							}
							,show: true
							,hide:false
						});
						
						$(xpath).attr("click_times",click_times);
					}
					init_btn()
					$("#total_click_times").html(len);
				}
				
			},"json"
		)
	}
	
	chg_show_mode = function(){
		var tooltipJS_loaded = $("body").data("toolitpJS_loaded")||false;
		if( !tooltipJS_loaded ){
			alert("JS尚未讀取，請稍待或聯絡管理員");
			return false;
		}
			
		if(show_mode=="%"){
			var len = Number( $("#total_click_times").html() );
			$("*[click_times]").each(function(){
				var click_times = $(this).attr("click_times");
				var content = String( Math.floor(click_times*100*10/len)/10)+"%";
				$(this).qtip('option', 'content.text', content );
			})
			
		}else if(show_mode=="數"){
			$("*[click_times]").each(function(){
				$(this).qtip('option', 'content.text', $(this).attr("click_times") );
			})
		}
		
	}
	
	$.getScript( tooltipJS_src, function(){
		$("body").data("toolitpJS_loaded",true);
		analysis()
	} );
	
})