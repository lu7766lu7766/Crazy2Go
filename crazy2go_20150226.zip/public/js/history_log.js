$(document).ready(function(){
	var site_url = "http://www.crazy2go.com/";
	var control_name = "history_log";
	var os = navigator.platform;
	var browser = navigator.userAgent;
	var page_enter = document.referrer;
	var page_now = document.URL;
	var obj_xpath = "";
	
    //console.log("os:"+os+"\nbrowser:"+browser+"\npage_enter:"+page_enter+"\npage_now:"+page_now);
    $.ajax({
		async: false,
		type: "POST",
		url: site_url+control_name+"/ajax_set_time_enter"
	});
		
	window.onunload = function unLoad(e) {
		
		if( obj_xpath=="" || obj_xpath=="/html" || obj_xpath=="/html/body" ){return;}
		console.log(obj_xpath)
		$.ajax({
			async: false,
			type: "POST",
			url: site_url+control_name+"/ajax_page_out",
			data: { 
				os: 		os,
				browser: 	browser, 
				page_enter: page_enter,
				page_now: page_now,
				obj_xpath: obj_xpath
			}
		}).done(function( msg ) {
			console.log( msg );
		});
		//console.log("os:"+os+"\nbrowser:"+browser+"\npage_enter:"+page_enter+"\npage_now:"+page_now+"\nurl:"+site_url+"history_log/page_out");
	}
	
	$("*").click(function(){
		tmp_path = $(this).getXPath();
		if( obj_xpath == ""){
			obj_xpath = tmp_path;
		}else{
			if( obj_xpath.indexOf(tmp_path) != 0){
				obj_xpath = tmp_path;
			}
		}
		setTimeout(function(){obj_xpath=""},2000);
	})
	$.fn.getXPath = function(rootNodeName){
		//other nodes may have the same XPath but because this function is used to determine the corresponding input name of a data node, index is not included 
		var position,
			$node = this.first(),
			nodeName = $node.prop('nodeName'),
			$sibSameNameAndSelf = $node.siblings(nodeName).addBack(),
			steps = [], 
			$parent = $node.parent(),
			parentName = $parent.prop('nodeName');
 
		position = ($sibSameNameAndSelf.length > 1) ? '['+($sibSameNameAndSelf.index($node)+1)+']' : '';
		steps.push(nodeName+position);
 
		while ($parent.length == 1 && parentName !== rootNodeName && parentName !== '#document'){
			$sibSameNameAndSelf = $parent.siblings(parentName).addBack();
			position = ($sibSameNameAndSelf.length > 1) ? '['+($sibSameNameAndSelf.index($parent)+1)+']' : '';
			steps.push(parentName+position);
			$parent = $parent.parent();
			parentName = $parent.prop('nodeName');
		}
		return '/'+steps.reverse().join('/').toLowerCase();
	};
})
