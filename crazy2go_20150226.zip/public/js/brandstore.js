$(document).ready(function(){
    $("#bs_product_list div[fi_no]").each(function(){
        $(this).hover(function(){
            var $this = $(this);
            $this.append("<a class='bs_product' href='#'><div style='position:absolute;display:inline-block;left:10px;top:10px;width:192px;height:270px;background:rgba(0,0,0,0.5);color:white;text-align:center;line-height:270px;'>加入購物車</div>");
        },function(){
            $(this).find(".bs_product").remove();
        });
    });
    var params = location.href.split('?')[1].split('&');
    var params_len = params.length;
    for(var i=0; i<params_len; i++)
    {
        if($.isArray(params[i]))continue;
        params[i]=params[i].split('=');
        if(params[i][0]=="sort")
        {
            switch(params[i][1])
            {
                case "comprehensive":
                    $("#filter_selection span").eq(0).css({
                        "border":"1px solid red",
                        "border-bottom":"1px solid white"
                    });
                    break;
                case "news":
                    $("#filter_selection span").eq(1).css({
                        "border":"1px solid red",
                        "border-bottom":"1px solid white"
                    });
                    break;
                case "sales":
                    $("#filter_selection span").eq(2).css({
                        "border":"1px solid red",
                        "border-bottom":"1px solid white"
                    });
                    break;
            }
        }
        switch(params[i][0])
        {
            case "brand":
                $(".template_center").height($(".template_center").height()-220);
                break;
            case "bskeyword":
                $("#bs_keyword").val(decodeURI(params[i][1]));
                break;
            case "lowprice":
                $("#bs_low_price").val(params[i][1]);
                break;
            case "highprice":
                $("#bs_high_price").val(params[i][1]);
                break;
            case "checkedlist":
                if(params[i][1]=="")break;
                var checked = params[i][1].split(",");
                var cLen = checked.length;
                for(var i = 0; i < cLen; i++)
                {
                    $("#bs_subset .td[fi_no='"+checked[i]+"'] input[type=checkbox]").prop("checked",true);
                }
                break;
        }
    }
    
    $("#filter_selection span").each(function(index){
        var $this = $(this);
        $this.css({
           "cursor":"pointer",
           "padding":"10px",
           "top":"-14px",
           "position":"absolute",
           "left":($this.width()+20)*index+"px",
           "height":"8px"
        });
        $this.click(function(){
            switch(index)
            {
                case 0:
                    location.href = $("#sorter > div div").eq(0).find("a").attr('href');
                    break;
                case 1:
                    location.href = $("#sorter > div div").eq(2).find("a").attr('href');
                    break;
                case 2:
                    location.href = $("#sorter > div div").eq(4).find("a").attr('href');
                    break;
            }
        });
    });
                            
    $("#bs_search").click(function(){
        var keyword = $("#bs_keyword").val();
        var low_price = $("#bs_low_price").val();
        var high_price = $("#bs_high_price").val();
        var checked_array = [];
        var url = location.href+"&";
        
        $("#bs_subset .td input[type=checkbox]:checked").each(function(){
            checked_array.push($(this).parent().attr("fi_no"));
        });
        checked_array = checked_array.join(",");
        if(keyword.length < 2 && keyword.length > 0)
        {
            alert("搜尋關鍵字至少2個字元！");
            return;
        }
        if(low_price != "" && high_price == "")
        {
            high_price = low_price;
        }
        else if(low_price == "" && high_price != "")
        {
            low_price = high_price;
        }
        if(url.search("bskeyword")!=-1)
        {
            url = url.replace(/&bskeyword=.*&/,"");
        }
        url = url + '&bskeyword='+keyword;
        if(url.search("lowprice")!=-1)
        {
            url = url.replace(/&lowprice=[a-zA-Z0-9]*&/,"");
        }
        url = url + '&lowprice='+low_price;
        if(url.search("highprice")!=-1)
        {
            url = url.replace(/&highprice=[a-zA-Z0-9]*&/,"");
        }
        url = url + '&highprice='+high_price;
        if(url.search("checkedlist")!=-1)
        {
            url = url.replace(/&checkedlist=[,a-zA-Z0-9]*&/,"");
        }
        url = url + '&checkedlist='+checked_array;
        url = url.replace(/&&/g,"&");
        location.href = url;
    });
    
    $("#ad_slide").each(function(){
        var $slide = $(this);
        $slide.find("div:first span:first").css({"background":"#FF1493"});
        $slide.find("div:first span").each(function(index){
            var $this = $(this);
            $this.css({"cursor":"pointer"});
            $this.mouseover(function(){
                $slide.find("div").not(":first").fadeOut();
                $slide.find("div:first span").css({"background":"gray"});
                $slide.find("div").eq(index+1).fadeIn();
                $slide.find("div:first span").eq(index).css({"background":"#FF1493"});
            });
        });
    });
    
    $("#brand_left_btn").click(function(){
        var $brand = $("#brand_slide");
        var count = $brand.find("span").size()-4;
        if(count>4)count = 4;
        if(count>0)
        for(var i=0;i<count;i++)
        $brand.append($brand.find("span:first"));
    });
    
    $("#brand_right_btn").click(function(){
        var $brand = $("#brand_slide");
        var count = $brand.find("span").size()-4;
        if(count>4)count = 4;
        if(count>0)
        for(var i=0;i<count;i++)
        $brand.prepend($brand.find("span:last"));
    });
    
});