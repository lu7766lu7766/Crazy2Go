$(function(){
   //Brand Slide
   $("#brand_left_btn,#brand_right_btn").css({"cursor":"pointer"});
   $("#brand_left_btn").click(function(){
       var $brand = $("#brand_slide");
       var count = $brand.find("span").size()-7;
       if(count>7)count = 7;
       if(count>0)
       for(var i=0;i<count;i++)
       $brand.append($brand.find("span:first"));
   });
   $("#brand_right_btn").click(function(){
       var $brand = $("#brand_slide");
       var count = $brand.find("span").size()-7;
       if(count>7)count = 7;
       if(count>0)
       for(var i=0;i<count;i++)
       $brand.prepend($brand.find("span:last"));
   });
   //Floor
   $(".floor").each(function(){
       var $floor = $(this);
       var $logo_slide = $floor.find(".logo_slide");
       var moveDis = $logo_slide.width();
       var current_posx = 0;
       var is_animated = false;
       //左右滑按鈕手勢圖
       $floor.find(".logo_slide_left_button,.logo_slide_right_button").css({"cursor":"pointer"});
       //初始化 logo slide 位置
       $logo_slide.find("div").each(function(index){
            var $this = $(this);
            $this.attr("index",index);
            $this.css({
               "position":"absolute",
               "left": $logo_slide.width()*index+"px",
               "top": "0px"
            });
        });
        //左滑
        $floor.find(".logo_slide_left_button").click(function(){
            if(is_animated)return;
            is_animated = true;
            $logo_slide.find("div").transition({
                x:current_posx-=moveDis
            },500,function(){
                if(is_animated)
                {
                    is_animated = false;
                    $logo_slide.find("div").transition({
                        x:current_posx+=moveDis
                    },0);
                    $logo_slide.append($logo_slide.find("div:first"));
                    $logo_slide.find("div").each(function(index){
                        var $this = $(this);
                        $this.attr("index",index);
                        $this.css({
                           "position":"absolute",
                           "left": $logo_slide.width()*index+"px",
                           "top": "0px"
                        });
                    });
                }
            })
        });
        //右滑
        $floor.find(".logo_slide_right_button").click(function(){
            if(is_animated)return;
            is_animated = true;
            $logo_slide.find("div").transition({
                x:current_posx-=moveDis
            },0);
            $logo_slide.prepend($logo_slide.find("div:last"));
            $logo_slide.find("div").each(function(index){
                var $this = $(this);
                $this.attr("index",index);
                $this.css({
                   "position":"absolute",
                   "left": $logo_slide.width()*index+"px",
                   "top": "0px"
                });
            });
            $logo_slide.find("div").transition({
                x:current_posx+=moveDis
            },500,function(){
                is_animated = false;
            });
        });
        
        //floor 右側 slide
        $floor.find(".floor_right_slide div:first span:first").css({"background":"#FF1493"});
        $floor.find(".floor_right_slide").each(function(){
            var $slide = $(this);
            $slide.find("div:first span").each(function(index){
                var $this = $(this);
                $this.css({"cursor":"pointer"});
                $this.mouseover(function(){
                    $slide.find("div").not(":first").fadeOut();
                    $slide.find("div:first span").css({"background":"gray"});
                    $slide.find("div").eq(index+1).fadeIn();
                    $slide.find("div:first span").eq(index).css({"background":"#FF1493"});
                });
            });
        });
   });
    //畫面最上方 slide
    var $primary = $("#primary_slide");
    $primary.find("div:first span:first").css({"background":"#FF1493"});
    $primary.find("div:first span").each(function(index){
        var $this = $(this);
        $this.css({"cursor":"pointer"});
        $this.mouseover(function(){
            $primary.find("div").not(":first").fadeOut();
            $primary.find("div:first span").css({"background":"gray"});
            $primary.find("div").eq(index+1).fadeIn();
            $primary.find("div:first span").eq(index).css({"background":"#FF1493"});
        });
    });
});