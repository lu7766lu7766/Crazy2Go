<?php
$lang['copyright'] = "版權所有\n";
?>